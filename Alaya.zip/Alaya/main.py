import discord
from discord.ext import commands
from discord.ui import View, Button
import requests
import difflib
import secret

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='$', intents=intents, help_command=None)

#Variables globales
respuestas_pendientes = {}

#FUNCIONES AUXILIARES
def construir_indice_servants(data):
    indice = {}
    for servant in data:
        nombres = set()

        for campo in ["name", "trueName", "battleName"]:
            valor = servant.get(campo)
            if valor:
                nombres.add(valor.strip().lower())

        for alias in servant.get("alias", []):
            nombres.add(alias.strip().lower())

        for nombre in nombres:
            if nombre not in indice:
                indice[nombre] = servant
    return indice

def buscar_coincidencias(nombre_usuario, indice):
    nombre_usuario = nombre_usuario.lower().strip()

    # Coincidencia exacta
    if nombre_usuario in indice:
        return [indice[nombre_usuario]]

    # Coincidencias parciales
    coincidencias = [s for nombre, s in indice.items() if nombre_usuario in nombre]

    if not coincidencias:
        sugerencias = difflib.get_close_matches(nombre_usuario, list(indice.keys()), n=3, cutoff=0.6)
        coincidencias = [indice[s] for s in sugerencias]

    return coincidencias

async def mostrar_servant(ctx, servant):
    imagen_url = servant["extraAssets"]["charaGraph"]["ascension"].get("1")
    embed = discord.Embed(
        title=servant["name"],
        description=f"**Clase:** {servant['className']}\n**Rareza:** {'⭐' * servant['rarity']}",
        color=discord.Color.blue()
    )
    if imagen_url:
        embed.set_image(url=imagen_url)

    await ctx.send(embed=embed)

#Comando de prueba $test
@bot.command()
async def test(ctx, *args):
    respuesta = ' '.join(args)
    await ctx.send(respuesta)

#Comando de bienvenida $start
@bot.command()
async def start(ctx):
    await ctx.send(f"Saludos {ctx.author.mention}\nYo soy Alaya, una entidad omnipresente que guía el mundo en equilibrio. Pregunta por cualquier héroe histórico y te mostraré su información.")

#Comando de ayuda $help
@bot.command(name="help")
async def help_command(ctx):
    mensaje = (
        "**Comandos disponibles:**\n"
        "```"
        "$start    - Mensaje de bienvenida\n"
        "$test     - Repite el mensaje que escribas\n"
        "$servant  - Busca información de un Servant (ejemplo: $servant Altria)\n"
        "$elegir   - Selecciona entre varios resultados si hay ambigüedad\n"
        "$borrar   - Borra mensajes del canal (ejemplo: $borrar 10)\n"
        "```"
    )
    await ctx.send(mensaje)

#Comando para buscar Servants
@bot.command()
async def servant(ctx, *, nombre: str):
    response = requests.get("https://api.atlasacademy.io/export/NA/nice_servant.json")
    if response.status_code != 200:
        await ctx.send("No se pudo acceder a la base de datos de Servants.")
        return

    data = response.json()
    indice = construir_indice_servants(data)
    coincidencias = buscar_coincidencias(nombre, indice)

    if not coincidencias:
        await ctx.send("No encontré ningún Servant con ese nombre.")
        return

    if len(coincidencias) == 1:
        await mostrar_servant(ctx, coincidencias[0])
        return

    respuestas_pendientes[ctx.author.id] = coincidencias

    lista = ""
    for i, s in enumerate(coincidencias, 1):
        lista += f"{i}. {s['name']} ({s['className']})  ⭐{s['rarity']}\n"

    await ctx.send(
        f"He encontrado resultados que coinciden con **{nombre}**:\nSelecciona con `$elegir (número)`\n\n{lista}"
    )

#Mostra coincidencias a elegir
@bot.command()
async def elegir(ctx, opcion: int):
    coincidencias = respuestas_pendientes.get(ctx.author.id)
    if not coincidencias:
        await ctx.send("No tienes ninguna búsqueda activa.")
        return

    if opcion < 1 or opcion > len(coincidencias):
        await ctx.send("Número inválido.")
        return

    servant = coincidencias[opcion - 1]
    await mostrar_servant(ctx, servant)
    respuestas_pendientes.pop(ctx.author.id, None)

#Borrar mensajes del canal
@bot.command()
@commands.has_permissions(manage_messages=True)
async def borrar(ctx, amount: int = 100):
    await ctx.channel.purge(limit=amount + 1)
    await ctx.send("Los mensajes anteriores han sido eliminados.", delete_after=5)

@borrar.error
async def borrar_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("No tengo permisos para borrar mensajes.")

#Mensaje de activacion
@bot.event
async def on_ready():
    print(f'El {bot.user} ha sido activado.')

bot.run(secret.TOKEN)